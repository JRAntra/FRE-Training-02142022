# FRE-Training-02142022

This is a repo to record the FRE-TRAINING assignments and notes.
## How to record your FEE-TRAINING assignments by using this repo:
### Clone this repo:
open your terminal
```bash
cd your_work_dir
git clone https://github.com/JRAntra/FRE-Training-02142022.git
```
### Create your feature branch to implement the assignment.
```bash
git branch by_your_name/notes
git checkout by_your_name/notes
implement the assignment under this feature branch.
``
