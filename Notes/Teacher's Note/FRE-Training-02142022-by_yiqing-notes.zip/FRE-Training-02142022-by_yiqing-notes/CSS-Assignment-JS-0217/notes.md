1. Responsive desgin
   - units: %, em, rem
   - media query
2. Mobile first vs. Desktop first
   - Mobile first: functional, mobile audience, content-first
   - Desktop first: traditional, office audience, feature-rich
3. BEM naming methodology
   - Block\_\_Element--Modifier
4. Primitive data type
   - number
   - undefined
   - string
   - boolean
   - null
   - symbol
   - bigint
5. == vs. ===
6. Coersion
7. Truthy vs. falsy
   - falsy: 0, -0, 0n, empty strings ('', "", ``), null, undefined, NaN, document.all
