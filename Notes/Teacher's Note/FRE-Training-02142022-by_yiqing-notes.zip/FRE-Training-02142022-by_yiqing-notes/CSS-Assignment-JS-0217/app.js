// console.log(typeof null);
// console.log(typeof undefined);
// console.log(typeof 1);
// console.log(typeof true);
// console.log(typeof 'name');

// let a = 1;
// const b = 2;
// var c = 3;
// function foo(input) {
//   input = 6;
//   console.log(input);
// }
// foo(c); //6
// console.log(c); //3

// var a = 5;
// var b = a;
// a = 10;
// console.log('a: ', a, 'b: ', b);
console.log(1 == '1'); //true
console.log(1 === '1'); //false
//Coersion
var result = true + false;
console.log(result); //1
//Truthy falsy
