1. 3 ways to implement CSS rules
   - External style sheet
   - Using style tag
   - Using inline attribute
     - Priority
     - Specificity
2. Pseudo class vs. Pseudo elements
3. CSS reset vs CSS normalization
   - CSS box model
   - box-sizing
4. Common CSS selectors
   - class
   - id
   - element
   - universal selector
   - attribute selector: Regex can be used
   - Descendent selector vs. child selector/combinator
5. Margin collapsing
6. CSS positions (positioned elements)
   - static
   - relative
   - absolute (normal document flow)
   - fixed
   - sticky
   - inherit
7. z-index
8. Flexbox
9. CSS grid
